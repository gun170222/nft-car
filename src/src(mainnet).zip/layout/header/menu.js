export const menuList = [
  {
    label: "Home",
    path: "/"
  },
  {
    label: "Cars",
    path: "/cars"
  },
  {
    label: "Dashboard",
    path: "/dashboard"
  },
]